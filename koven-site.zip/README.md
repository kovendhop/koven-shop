# KOVEN

Site vitrine gratuit pour la marque KOVEN.

## Fichiers
- `index.html` : structure du site
- `style.css` : design

## Pour mettre en ligne gratuitement
1. Crée un compte GitHub avec l'aide de ton parent/responsable si nécessaire.
2. Crée un dépôt nommé `koven-shop`.
3. Ajoute `index.html` et `style.css`.
4. Dans les réglages du dépôt, active GitHub Pages depuis la branche principale.
5. Ton adresse sera de la forme `https://TON-PSEUDO.github.io/koven-shop/`.

Le site actuel est une maquette : aucun paiement ni commande réelle n'est intégré.
